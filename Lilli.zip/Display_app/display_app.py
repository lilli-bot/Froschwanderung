from flask import Flask, redirect, render_template, request
import redis
import random
import urllib.parse


app = Flask(__name__)
r = redis.Redis(host="localhost", port=6379, db=0)


@app.route("/")
def index():
    count = r.get("counter").decode("utf-8")
    num = random.randint(1, 100)
    img_url = f"https://picsum.photos/seed/{num}/{int(count)*500}"
    return render_template("index.html", img_url=img_url)


@app.before_request
def generate_image():
    if request.endpoint == "index":
        current_count = r.get("counter").decode("utf-8")
        previous_count = request.args.get("count")
        if current_count != previous_count:
            num = random.randint(1, 100)
            img_url = f"https://picsum.photos/seed/{num}/{int(current_count)*500}"
            return redirect(
                f"/?"
                + urllib.parse.urlencode({"count": current_count, "img_url": img_url})
            )


@app.before_request
def trigger_refresh():
    if request.endpoint == "index":
        current_count = r.get("counter").decode("utf-8")
        previous_count = request.args.get("count")
        if current_count != previous_count:
            return None
        else:
            return redirect(request.url)


if __name__ == "__main__":
    app.run(debug=True, port=5001)
