import redis
from flask import Flask, redirect, render_template, request

app = Flask(__name__)

r = redis.Redis(host="localhost", port=6379, db=0)
r.set("counter", 0)


@app.route("/")
def index():
    count = r.get("counter").decode("utf-8")
    return render_template("index.html", count=count)


@app.route("/incr", methods=["POST"])
def incr():
    r = redis.Redis(host="localhost", port=6379, db=0)
    r.incr("counter")
    return redirect("/")


if __name__ == "__main__":
    app.run(debug=True)
